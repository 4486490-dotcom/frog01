# ENVIRONMENT.md — факты среды (проверено зондами 2026-09-27, не верь тексту правил слепо — §12.4)

## Железо / ОС
- CPU: 2 ядра. RAM: MemTotal 1058 MB (~1 ГБ, как в §0.2), MemAvailable ~900 MB.
- Диск: ~9.3 GB свободно в /home/user. Load низкий.
- Дата песочницы на момент зонда: 2026-09-26T18:20Z (контейнерное время может отличаться от локального).

## Софт (presence проверен `command -v`)
- ЕСТЬ: git 2.39.5, python3 3.11.2 (+pip3), node v20.20.2, npm 10.8.2, tar, gzip, sha256sum, setsid.
- НЕТ: curl, wget, zip, unzip, ps, free (подтверждает §12.3; `free`/`ps` заменяем чтением /proc).
- Python stdlib: zipfile, tarfile, urllib.request, json, ssl, socket — OK.
- gdown: ОТСУТСТВУЕТ (дрейф относительно §12.4!). При необходимости: `pip install gdown` (~10–20 с, pure-python).
- HTTP egress: РАБОТАЕТ (urllib → https://example.com → 200 за 0.1 с на холодную).

## Правила песочницы (из system-контекста + AGENT_RULES)
- Снимок рабочей области: только /home/user; исключены каталоги build/dist/out/target/node_modules/
  __pycache__/.venv/.cache/.next/coverage/logs-кэши и .git/config, .git/credentials, .netrc (§8.2).
  ВНИМАНИЕ: logs/ в этой песочнице НЕ исключён, но в бандл не кладём (§10.3).
- Лимит снимка ~128 МБ / 10 000 файлов (§8.4).
- Один вызов инструмента ≤ 20 с реального времени, всегда явный timeout (§0.1).
- Фон — только scripts/bg.sh + короткий опрос tail (§0.3).
- Тяжёлые фоновые job'ы: BG_ULIMIT_V=524288 bash scripts/bg.sh ... (§0.8).
- Интерпретаторы в фоне: python3 -u, маркеры BG-START/BG-DONE (§0.9).

## Рабочие замены отсутствующего
- HTTP: python3 urllib.request (не curl/wget).
- Архивы: python3 -m zipfile (распаковка: -e), tar (не zip/unzip).
- Процессы: /proc/<pid>/comm, зомби: grep /proc/[0-9]*/status (не ps).
- Память: /proc/meminfo (не free).

## Обновлять этот файл при каждом холодном старте (doctor.sh печатает актуальные факты).

#!/usr/bin/env bash
# doctor.sh — короткий зонд среды + лёгкое лечение (AGENT_RULES 7.3, 11.3).
# Без сети и установок; обязан завершаться < 10 с. Факты среды — в ENVIRONMENT.md.
set -u
cd "$(dirname "$0")/.." || exit 1
say(){ printf '%s\n' "$*"; }
say "DOCTOR-START $(date -Is)"

# 1. Ресурсы (free/ps в песочнице НЕТ — читаем /proc)
say "CPU=$(nproc 2>/dev/null || echo '?') $(awk '/MemAvailable/{print "RAM_avail="int($2/1024)"MB"}' /proc/meminfo 2>/dev/null) $(df -h . 2>/dev/null | awk 'NR==2{print "DISK_avail="$4}') load=$(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null)"

# 2. Обязательные бинарники
miss=""
for c in git python3 tar gzip sha256sum setsid; do
  command -v "$c" >/dev/null 2>&1 || miss="$miss $c"
done
[ -z "$miss" ] && say "BINARIES: OK" || say "BINARIES MISSING:$miss"
# Известно отсутствующие (12.3) — только констатируем дрейф
for c in curl wget zip unzip ps free; do
  command -v "$c" >/dev/null 2>&1 && say "DRIFT: $c появился — обнови ENVIRONMENT.md"
done

# 3. Python-модули
python3 - <<'PY' 2>&1 | head -4
import importlib.util
bad=[m for m in ("zipfile","tarfile","urllib","json","ssl","socket") if importlib.util.find_spec(m) is None]
print("PY-MODULES:", "OK" if not bad else "MISSING "+",".join(bad))
try:
    import gdown; print("gdown:", gdown.__version__)
except Exception as e:
    print("gdown: MISSING ("+type(e).__name__+") — при нужде: pip install gdown, ~10-20 с (12.4)")
PY

# 4. Структура каталогов (8.3)
mkdir -p scripts logs reports docs release checkpoints attic src
say "DIRS: OK"

# 5. Git-идентичность (3.1) — .git/config НЕ переживает смену чата
if [ -d .git ]; then
  git config user.email "agent@local"; git config user.name "agent"
  say "GIT: identity OK; last: $(git log -1 --format='%h %s' 2>/dev/null | head -c 70 || echo 'нет коммитов')"
else
  say "GIT: репозитория нет — запусти scripts/bootstrap.sh"
fi

# 6. Зомби (без ps — по /proc) и последствия прерванных установок (0.2)
z=$(grep -l '^State:.*Z' /proc/[0-9]*/status 2>/dev/null | wc -l)
say "ZOMBIES: ${z:-0}"
if command -v dpkg >/dev/null 2>&1; then
  a=$(dpkg --audit 2>/dev/null | head -2)
  if [ -n "$a" ]; then say "DPKG-AUDIT: $a"; else say "DPKG: clean"; fi
fi

# 7. HANDOFF и контрольные суммы (11.5)
[ -f HANDOFF.md ] && say "HANDOFF: $(head -1 HANDOFF.md | head -c 90)" || say "HANDOFF.md: MISSING"
if [ -f release/CHECKSUMS.txt ]; then
  sha256sum -c release/CHECKSUMS.txt 2>&1 | tail -3
else
  say "CHECKSUMS: нет артефактов в release/ (ок)"
fi
say "DOCTOR-DONE rc=0"

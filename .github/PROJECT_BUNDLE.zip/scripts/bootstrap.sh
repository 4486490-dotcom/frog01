#!/usr/bin/env bash
# bootstrap.sh — холодный старт (AGENT_RULES 3.1, 7.2, 11). Запускать РАЗ при новом чате/песочнице.
set -u
cd "$(dirname "$0")/.." || exit 1
mkdir -p scripts logs reports docs release checkpoints attic src
bash scripts/doctor.sh || true
if [ ! -d .git ]; then
  git init -q . || { echo "BOOTSTRAP-FAIL: git init"; exit 1; }
fi
# 3.1: идентичность выставляем КАЖДЫЙ холодный старт (.git/config не переживает снимок)
git config user.email "agent@local"
git config user.name "agent"
git add -A 2>/dev/null || true
git commit -q -m "bootstrap: холодный старт, каркас scripts/+HANDOFF+ENVIRONMENT" 2>/dev/null \
  || echo "GIT: коммит не создан (нечего или уже есть) — не критично"
echo "BOOTSTRAP-DONE $(date -Is)"
echo "Дальше: HANDOFF.md -> раздел СЛЕДУЮЩИЙ ШАГ"

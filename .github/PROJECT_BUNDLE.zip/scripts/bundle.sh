#!/usr/bin/env bash
# bundle.sh — сборка PROJECT_BUNDLE.zip для передачи между чатами (AGENT_RULES 10.2-10.3, 12.3).
# ВКЛЮЧАЕМ: AGENT_RULES.md HANDOFF.md ENVIRONMENT.md scripts/ src/ game/ reports/ docs/ release/CHECKSUMS.txt
# ИСКЛЮЧАЕМ: logs/ node_modules/ checkpoints/ attic/ uploads/ .git/ и все snapshot-excluded каталоги.
# Бинарника zip НЕТ — используем python3 -m zipfile.
set -u
cd "$(dirname "$0")/.." || exit 1
python3 - <<'PY'
import os, zipfile, hashlib
INC_FILES = ["AGENT_RULES.md", "HANDOFF.md", "ENVIRONMENT.md", "release/CHECKSUMS.txt"]
INC_DIRS  = ["scripts", "src", "game", "reports", "docs"]
SKIP_DIRS = {"node_modules","__pycache__",".git","logs","checkpoints","attic","uploads",
             ".venv","dist","build","out","target",".cache",".next",".npm",".vite","coverage"}
MAX_FILE  = 8*1024*1024  # 8 МБ на файл — бережём лимит снимка 128 МБ (8.4)
out = "PROJECT_BUNDLE.zip"
n = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for f in INC_FILES:
        if os.path.isfile(f):
            z.write(f); n += 1
    for d in INC_DIRS:
        if not os.path.isdir(d):
            continue
        for root, dirs, files in os.walk(d):
            dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
            for name in sorted(files):
                p = os.path.join(root, name)
                try:
                    if os.path.getsize(p) > MAX_FILE:
                        print("SKIP-large:", p); continue
                    z.write(p); n += 1
                except Exception as e:
                    print("SKIP:", p, type(e).__name__)
data = open(out, "rb").read()
h = hashlib.sha256(data).hexdigest()
import datetime
line = f"{datetime.date.today().isoformat()} files={n} size={len(data)} sha256={h}"
open(os.path.join("release", "BUNDLE_LATEST.txt"), "w").write(line + "\n")
print("BUNDLE:", line)
PY
echo "BUNDLE-DONE $(date -Is)"

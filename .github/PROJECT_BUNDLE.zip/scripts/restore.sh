#!/usr/bin/env bash
# restore.sh — восстановление рабочего состояния ОДНОЙ командой (AGENT_RULES 3.4).
# Берёт свежайший checkpoints/cp-*.tar.gz либо путь из $1.
set -u
cd "$(dirname "$0")/.." || exit 1
cp_file="${1:-}"
if [ -z "$cp_file" ]; then
  cp_file=$(ls -1t checkpoints/cp-*.tar.gz 2>/dev/null | head -1)
fi
if [ -z "$cp_file" ] || [ ! -f "$cp_file" ]; then
  echo "RESTORE-FAIL: чекпоинт не найден (checkpoints/cp-*.tar.gz)"; exit 1
fi
echo "RESTORE: распаковываю $cp_file"
tar -xzf "$cp_file" || { echo "RESTORE-FAIL: ошибка tar"; exit 1; }
# 3.1: идентичность git не переживает снимок — восстанавливаем
git config user.email "agent@local" 2>/dev/null || true
git config user.name "agent" 2>/dev/null || true
bash scripts/doctor.sh >/dev/null 2>&1 || true
echo "RESTORE-DONE $(date -Is) из $cp_file"

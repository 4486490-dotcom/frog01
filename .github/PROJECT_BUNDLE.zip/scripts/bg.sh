#!/usr/bin/env bash
# bg.sh — безопасный запуск фона (AGENT_RULES 0.3, 0.8, 0.9).
# Использование: bash scripts/bg.sh <имя> <команда...>
#   Пример: bash scripts/bg.sh smoke bash -c 'echo a; sleep 2; echo b'
#   Тяжёлый job: BG_ULIMIT_V=524288 bash scripts/bg.sh heavy python3 -u worker.py
# Пишет в logs/<имя>.log: заголовок BG-START, вывод команды, строку BG-DONE rc=N.
# Возвращается МГНОВЕННО: setsid + все три потока в файл + </dev/null.
# Опрос — отдельными короткими вызовами: tail -n 30 logs/<имя>.log
# Живость процесса: cat /proc/<wrapper-pid>/comm (не pgrep -f! — правило 0.7).
set -u
name="${1:?usage: bg.sh <имя> <команда...>}"
shift
[ "$#" -ge 1 ] || { echo "bg.sh: команда не задана" >&2; exit 2; }
mkdir -p logs
log="logs/${name}.log"
{
  echo "# === $(date -Is) BG-START name=${name}"
  echo "# cmd: $*"
} >> "$log"
export BG_ULIMIT_V="${BG_ULIMIT_V:-}"
setsid bash -c '
  if [ -n "${BG_ULIMIT_V:-}" ]; then
    ulimit -v "${BG_ULIMIT_V}" 2>/dev/null || echo "# ulimit -v не выставлен, работаю без лимита"
  fi
  echo "# wrapper-pid=$$ $(date -Is)"
  "$@"
  rc=$?
  echo "# $(date -Is) BG-DONE rc=${rc}"
  exit "${rc}"
' _ "$@" >> "$log" 2>&1 < /dev/null &
pid=$!
disown "$pid" 2>/dev/null || true
echo "BG-LAUNCH name=${name} log=${log} (wrapper-pid см. в логе)"
